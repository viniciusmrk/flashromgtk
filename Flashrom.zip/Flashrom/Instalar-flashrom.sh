#!/bin/bash
senha=$(zenity --password)
echo $senha | sudo -S +senha
sudo apt install flashrom -y
sudo mv flashrom /opt/
sudo chmod +x /opt/flashrom/flashrom.sh
echo -e '[Desktop Entry]
Encoding=UTF-8
Type=Application
Name=Flashrom
Comment=Flashrom
Icon=/opt/flashrom/chip.ico
Exec=/opt/flashrom/flashrom.sh
StartupNotify=false
Terminal=false' | sudo tee /usr/share/applications/Flashrom.desktop
zenity --info --text="Instalação Concluido!." --width="120" height="50"
exit 0
